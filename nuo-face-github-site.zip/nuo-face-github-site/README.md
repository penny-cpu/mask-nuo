# 傩面具五官组合器

这是一个 GitHub Pages 可部署的网页项目，支持用户交互式切换傩面具的“头饰、眼睛、鼻子、嘴”组成方式。  
点击按钮可组合生成不同面具，页面风格融合东方宣纸与传统图腾纹样风格。

## 如何使用

1. 上传整个项目到 GitHub 仓库（例如 `nuo-face-generator`）
2. 启用 GitHub Pages（Settings → Pages → source: `main` + folder: `/docs`）
3. 访问部署地址，例如：  
   `https://penny-cpu.github.io/nuo-face-generator/`

所有图像文件均嵌入在 `docs/assets/` 文件夹中。
